import pyautogui
import time

#pyautogui.position() > vai registrar a exata posição de clique do seu mouse

time.sleep(3)
print(pyautogui.position()) 