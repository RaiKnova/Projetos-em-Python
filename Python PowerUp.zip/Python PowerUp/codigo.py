import pyautogui
import time
import pandas 

# pyautogui.write() > escrever um texto
# pyautogui.click() > clicar com o mouse - 
# pyautogui.press() > apertar uma tecla
# pyautogui.hotkey() > apertar um atalho de teclado (ctrl, c)
# pyautogui.PAUSE > cria um tempo de espera entre um comando e outro
#pyautogui.scroll() > faz a função de rolar do mouse, basta definir os pixels que serão rolados, seja para cima (ex: 1000) ou para baixo (ex: -1000) 

# time.sleep() > define um tempo de espera ESPECIFICO para o intervalo de um comando e outro

# tabela.loc > busca as informações da planilha através das coordenadas que você definir

# a diferença é que o pyautogui.pause se aplica ao código todo, exceto nas condições especificas, como o time.sleep

link = "https://dlp.hashtagtreinamentos.com/python/intensivao/login"
email = "exemplo@gmail.com"
senha = "senha123456numerosaaaa"

pyautogui.PAUSE = 0.8

pyautogui.press("win")
pyautogui.write("Chrome")
pyautogui.press("enter")

pyautogui.write(link)
pyautogui.press("enter")

time.sleep(1.5)

pyautogui.click(x=934, y=325) # caso tenha dúvida da posição especifica do clique, utilize o 'auxiliar.py'
pyautogui.write(email)

pyautogui.press("tab")
pyautogui.write(senha)

pyautogui.press("tab")
pyautogui.press("enter")

pyautogui.click(x=851, y=234) 

time.sleep(1.5)

tabela = pandas.read_csv("produtos.csv")

print(tabela)

# texto = string = str()

linha = 0

for linha in tabela.index:

    pyautogui.click(x=851, y=234)

    codigo = tabela.loc [linha, "codigo"] # [a partir de qual linha devo começar?, qual o nome da coluna que contém as informações que irei registrar?]

    pyautogui.write(str(codigo))
    pyautogui.press("tab")


    marca = tabela.loc [linha, "marca"]

    pyautogui.write(str(marca))
    pyautogui.press("tab")

    tipo = tabela.loc [linha, "tipo"] 

    pyautogui.write(str(tipo))
    pyautogui.press("tab")

    categoria = tabela.loc [linha, "categoria"]

    pyautogui.write(str(categoria))
    pyautogui.press("tab")

    preco_unitario = tabela.loc [linha, "preco_unitario"] 

    pyautogui.write(str(preco_unitario))
    pyautogui.press("tab")

    custo = tabela.loc [linha, "custo"] 

    pyautogui.write(str(custo))
    pyautogui.press("tab")

    obs = tabela.loc [linha, "obs"] 

    if not pandas.isna(obs): # Se 'obs' não for nulo, escrever seu valor
        pyautogui.write(str(obs))
    pyautogui.press("tab")  

    pyautogui.press("enter")
    pyautogui.scroll(4500)

    time.sleep(1.5)

# caso precise encerrar o loop, coloque a ponta do mouse no topo superior esquerdo da sua TELA











